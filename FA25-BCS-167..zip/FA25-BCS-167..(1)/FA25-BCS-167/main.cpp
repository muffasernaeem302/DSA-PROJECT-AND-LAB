#include <iostream>
#include <string>
using namespace std;

// --- Linear Linked List ---
struct LinearNode {
    int element;
    LinearNode* link;
    LinearNode(int val) : element(val), link(nullptr) {}
};

class LinearLinkedList {
private:
    LinearNode* startNode;

    void helperReverse(LinearNode* nodePtr) {
        if (!nodePtr) return;
        helperReverse(nodePtr->link);
        cout << nodePtr->element << " -> ";
    }

public:
    LinearLinkedList() : startNode(nullptr) {}

    void append(int num) {
        LinearNode* newNode = new LinearNode(num);
        if (!startNode) { startNode = newNode; return; }
        LinearNode* traveler = startNode;
        while (traveler->link) traveler = traveler->link;
        traveler->link = newNode;
    }

    void showList() {
        LinearNode* traveler = startNode;
        while (traveler) {
            cout << traveler->element << " -> ";
            traveler = traveler->link;
        }
        cout << "NULL\n";
    }

    void showReverse() {
        cout << "Reversed Sequence: ";
        helperReverse(startNode);
        cout << "NULL\n";
    }

    void invertList() {
        LinearNode* previousNode = nullptr;
        LinearNode* currentPtr = startNode;
        LinearNode* nextNode = nullptr;

        while (currentPtr) {
            nextNode = currentPtr->link;
            currentPtr->link = previousNode;
            previousNode = currentPtr;
            currentPtr = nextNode;
        }
        startNode = previousNode;
        cout << "List successfully inverted.\n";
    }

    void purgeDuplicates() {
        if (!startNode) return;
        LinearNode* currentPtr = startNode;
        while (currentPtr) {
            LinearNode* runnerNode = currentPtr;
            while (runnerNode->link) {
                if (runnerNode->link->element == currentPtr->element) {
                    LinearNode* duplicateNode = runnerNode->link;
                    runnerNode->link = runnerNode->link->link;
                    delete duplicateNode;
                } else {
                    runnerNode = runnerNode->link;
                }
            }
            currentPtr = currentPtr->link;
        }
        cout << "Duplicates purged.\n";
    }

    bool hasCycle() {
        LinearNode* slowPtr = startNode;
        LinearNode* fastPtr = startNode;
        while (fastPtr && fastPtr->link) {
            slowPtr = slowPtr->link;
            fastPtr = fastPtr->link->link;
            if (slowPtr == fastPtr) return true;
        }
        return false;
    }

    void locateMiddle() {
        if (!startNode) { cout << "The list is empty.\n"; return; }
        LinearNode* slowPtr = startNode;
        LinearNode* fastPtr = startNode;
        LinearNode* previousNode = nullptr;

        while (fastPtr && fastPtr->link) {
            previousNode = slowPtr;
            slowPtr = slowPtr->link;
            fastPtr = fastPtr->link->link;
        }
        if (!fastPtr && previousNode) cout << "Even length. Left mid: " << previousNode->element << "\n";
        else cout << "Middle item: " << slowPtr->element << "\n";
    }

    void segregateEvenOdd() {
        LinearNode* evenHead = nullptr;
        LinearNode* evenTail = nullptr;
        LinearNode* oddHead = nullptr;
        LinearNode* oddTail = nullptr;
        LinearNode* currentPtr = startNode;

        while (currentPtr) {
            LinearNode* nextNode = currentPtr->link;
            currentPtr->link = nullptr;
            if (currentPtr->element % 2 == 0) {
                if (!evenHead) evenHead = evenTail = currentPtr;
                else { evenTail->link = currentPtr; evenTail = currentPtr; }
            } else {
                if (!oddHead) oddHead = oddTail = currentPtr;
                else { oddTail->link = currentPtr; oddTail = currentPtr; }
            }
            currentPtr = nextNode;
        }

        cout << "Even Elements: ";
        for (LinearNode* t = evenHead; t; t = t->link) cout << t->element << " -> ";
        cout << "NULL\n";

        cout << "Odd Elements: ";
        for (LinearNode* t = oddHead; t; t = t->link) cout << t->element << " -> ";
        cout << "NULL\n";
        startNode = nullptr;
    }

    void invertHalves() {
        int length = 0;
        LinearNode* traveler = startNode;
        while (traveler) { length++; traveler = traveler->link; }
        if (length < 2) return;

        int midPoint = length / 2;
        LinearNode* firstEnd = startNode;
        for (int i = 1; i < midPoint; i++) firstEnd = firstEnd->link;

        LinearNode* secondStart = firstEnd->link;
        firstEnd->link = nullptr;

        LinearNode* previousNode = nullptr;
        LinearNode* currentPtr = startNode;
        LinearNode* nextNode = nullptr;

        while (currentPtr) {
            nextNode = currentPtr->link;
            currentPtr->link = previousNode;
            previousNode = currentPtr;
            currentPtr = nextNode;
        }
        LinearNode* newFirstHead = previousNode;
        startNode->link = secondStart;
        startNode = newFirstHead;

        previousNode = nullptr;
        currentPtr = secondStart;
        while (currentPtr) {
            nextNode = currentPtr->link;
            currentPtr->link = previousNode;
            previousNode = currentPtr;
            currentPtr = nextNode;
        }

        traveler = startNode;
        while (traveler->link) traveler = traveler->link;
        traveler->link = previousNode;
        cout << "Halves inverted individually.\n";
    }

    void removeMatching(int targetVal) {
        while (startNode && startNode->element == targetVal) {
            LinearNode* targetNode = startNode;
            startNode = startNode->link;
            delete targetNode;
        }
        LinearNode* currentPtr = startNode;
        while (currentPtr && currentPtr->link) {
            if (currentPtr->link->element == targetVal) {
                LinearNode* targetNode = currentPtr->link;
                currentPtr->link = currentPtr->link->link;
                delete targetNode;
            } else {
                currentPtr = currentPtr->link;
            }
        }
        cout << "All instances of " << targetVal << " removed.\n";
    }

    void exchangePairs() {
        if (!startNode || !startNode->link) return;
        LinearNode* dummyNode = new LinearNode(0);
        dummyNode->link = startNode;
        LinearNode* previousNode = dummyNode;

        while (previousNode->link && previousNode->link->link) {
            LinearNode* nodeA = previousNode->link;
            LinearNode* nodeB = previousNode->link->link;
            nodeA->link = nodeB->link;
            nodeB->link = nodeA;
            previousNode->link = nodeB;
            previousNode = nodeA;
        }
        startNode = dummyNode->link;
        delete dummyNode;
        cout << "Adjacent pairs swapped.\n";
    }
};


// --- Doubly Linked List ---
struct DualNode {
    string textData;
    DualNode* backLink;
    DualNode* frontLink;
    DualNode(string val) : textData(val), backLink(nullptr), frontLink(nullptr) {}
};

class DualLinkedList {
private:
    DualNode* rootNode;

public:
    DualLinkedList() : rootNode(nullptr) {}

    void addNode(string text) {
        DualNode* freshNode = new DualNode(text);
        if (!rootNode) { rootNode = freshNode; return; }
        DualNode* traveler = rootNode;
        while (traveler->frontLink) traveler = traveler->frontLink;
        traveler->frontLink = freshNode;
        freshNode->backLink = traveler;
    }

    void displayForward() {
        DualNode* traveler = rootNode;
        while (traveler) {
            cout << traveler->textData << " <-> ";
            traveler = traveler->frontLink;
        }
        cout << "NULL\n";
    }

    void reverseDeskMirror() {
        if (!rootNode || !rootNode->frontLink) return;
        DualNode* leftPtr = rootNode;
        DualNode* rightPtr = rootNode;
        while (rightPtr->frontLink) rightPtr = rightPtr->frontLink;

        while (leftPtr != rightPtr && leftPtr->backLink != rightPtr) {
            string tempVal = leftPtr->textData;
            leftPtr->textData = rightPtr->textData;
            rightPtr->textData = tempVal;
            leftPtr = leftPtr->frontLink;
            rightPtr = rightPtr->backLink;
        }
        cout << "Nodes mirrored successfully.\n";
    }

    void alternateFlipEdges() {
        if (!rootNode || !rootNode->frontLink || !rootNode->frontLink->frontLink) return;
        DualNode* leftPtr = rootNode->frontLink;
        DualNode* rightPtr = rootNode;
        while (rightPtr->frontLink) rightPtr = rightPtr->frontLink;
        rightPtr = rightPtr->backLink;

        bool activeFlag = true;
        while (leftPtr != rightPtr && leftPtr->backLink != rightPtr) {
            if (activeFlag) {
                string tempVal = leftPtr->textData;
                leftPtr->textData = rightPtr->textData;
                rightPtr->textData = tempVal;
            }
            leftPtr = leftPtr->frontLink;
            rightPtr = rightPtr->backLink;
            activeFlag = !activeFlag;
        }
        cout << "Alternate edge swap completed.\n";
    }
};


// --- Circular Linked List ---
struct TaskItem {
    string taskTitle, taskPrio, taskState;
    TaskItem* ringNext;
    TaskItem(string name, string pr, string st) : taskTitle(name), taskPrio(pr), taskState(st), ringNext(nullptr) {}
};

class RingTaskList {
private:
    TaskItem* startRing;

public:
    RingTaskList() : startRing(nullptr) {}

    void insertTask(string title, string priority, string state) {
        TaskItem* newItem = new TaskItem(title, priority, state);
        if (!startRing) {
            startRing = newItem;
            startRing->ringNext = startRing;
            cout << "Task registered.\n";
            return;
        }
        TaskItem* traveler = startRing;
        while (traveler->ringNext != startRing) traveler = traveler->ringNext;
        traveler->ringNext = newItem;
        newItem->ringNext = startRing;
        cout << "Task registered.\n";
    }

    void deleteByName(string title) {
        if (!startRing) { cout << "Empty list.\n"; return; }
        TaskItem* currentPtr = startRing;
        TaskItem* previousPtr = nullptr;

        do {
            if (currentPtr->taskTitle == title) {
                if (currentPtr == startRing && startRing->ringNext == startRing) {
                    delete startRing;
                    startRing = nullptr;
                    cout << "Task deleted. List now empty.\n";
                    return;
                }
                if (currentPtr == startRing) {
                    TaskItem* tailNode = startRing;
                    while (tailNode->ringNext != startRing) tailNode = tailNode->ringNext;
                    startRing = startRing->ringNext;
                    tailNode->ringNext = startRing;
                } else {
                    previousPtr->ringNext = currentPtr->ringNext;
                }
                delete currentPtr;
                cout << "Task removed successfully.\n";
                return;
            }
            previousPtr = currentPtr;
            currentPtr = currentPtr->ringNext;
        } while (currentPtr != startRing);
        cout << "Task not found.\n";
    }

    void showTasks() {
        if (!startRing) { cout << "No tasks available.\n"; return; }
        TaskItem* traveler = startRing;
        cout << "\n--- CIRCULAR TASK REGISTRY ---\n";
        do {
            cout << "Title: " << traveler->taskTitle << " | Priority: " << traveler->taskPrio << " | Status: " << traveler->taskState << "\n";
            traveler = traveler->ringNext;
        } while (traveler != startRing);
    }

    void changeStatus(string title, string updatedState) {
        if (!startRing) return;
        TaskItem* traveler = startRing;
        do {
            if (traveler->taskTitle == title) {
                traveler->taskState = updatedState;
                cout << "Status updated.\n";
                return;
            }
            traveler = traveler->ringNext;
        } while (traveler != startRing);
        cout << "Task not found.\n";
    }

    static void runJosephus(int totalPeople, int interval) {
        if (totalPeople <= 0) return;
        struct PersonNode {
            int idNum;
            PersonNode* nextPerson;
            PersonNode(int identifier) : idNum(identifier), nextPerson(nullptr) {}
        };

        PersonNode* ringHead = new PersonNode(1);
        PersonNode* prevNode = ringHead;
        for (int i = 2; i <= totalPeople; i++) {
            prevNode->nextPerson = new PersonNode(i);
            prevNode = prevNode->nextPerson;
        }
        prevNode->nextPerson = ringHead;

        PersonNode* currentPtr = ringHead;
        prevNode = nullptr;

        while (currentPtr->nextPerson != currentPtr) {
            for (int i = 1; i < interval; i++) {
                prevNode = currentPtr;
                currentPtr = currentPtr->nextPerson;
            }
            prevNode->nextPerson = currentPtr->nextPerson;
            cout << "Person " << currentPtr->idNum << " eliminated.\n";
            delete currentPtr;
            currentPtr = prevNode->nextPerson;
        }
        cout << "Survivor ID: " << currentPtr->idNum << "\n";
        delete currentPtr;
    }
};


// --- Main Driver Program ---
int main() {
    LinearLinkedList lList;
    DualLinkedList dList;
    RingTaskList rList;
    int menuSelection, innerOption, numVal, totalCount, skipStep;
    string textVal, priorityVal, stateVal;

    do {
        cout << "\n==================================\n";
        cout << "    DATA STRUCTURES PROJECT 1     \n";
        cout << "==================================\n";
        cout << "1. Linear Linked List Manager\n";
        cout << "2. Two-Way Linked List Manager\n";
        cout << "3. Ring Linked List Manager\n";
        cout << "0. Terminate Application\n";
        cout << "Choose an option: ";
        cin >> menuSelection;

        switch (menuSelection) {
            case 1:
                do {
                    cout << "\n--- LINEAR LINKED LIST OPERATIONS ---\n";
                    cout << "1. Insert Value\n2. View List\n3. View Reverse\n4. Invert List\n";
                    cout << "5. Clear Duplicates\n6. Check Loop\n7. Get Middle Element\n8. Split Even/Odd\n";
                    cout << "9. Invert Halves Separately\n10. Remove All Matches\n11. Swap Adjacent Pairs\n0. Return\n";
                    cout << "Select choice: ";
                    cin >> innerOption;
                    switch (innerOption) {
                        case 1: cout << "Enter number: "; cin >> numVal; lList.append(numVal); break;
                        case 2: lList.showList(); break;
                        case 3: lList.showReverse(); break;
                        case 4: lList.invertList(); break;
                        case 5: lList.purgeDuplicates(); break;
                        case 6: cout << (lList.hasCycle() ? "Loop Detected!\n" : "No Loop.\n"); break;
                        case 7: lList.locateMiddle(); break;
                        case 8: lList.segregateEvenOdd(); break;
                        case 9: lList.invertHalves(); break;
                        case 10: cout << "Enter value to purge: "; cin >> numVal; lList.removeMatching(numVal); break;
                        case 11: lList.exchangePairs(); break;
                    }
                } while (innerOption != 0);
                break;

            case 2:
                do {
                    cout << "\n--- TWO-WAY LINKED LIST OPERATIONS ---\n";
                    cout << "1. Add Node\n2. Show Forward\n";
                    cout << "3. Mirror Reverse Desks\n4. Alternate Swap Edges\n0. Return\n";
                    cout << "Select choice: ";
                    cin >> innerOption;
                    switch (innerOption) {
                        case 1: cout << "Enter entry name: "; cin >> textVal; dList.addNode(textVal); break;
                        case 2: dList.displayForward(); break;
                        case 3: dList.reverseDeskMirror(); break;
                        case 4: dList.alternateFlipEdges(); break;
                    }
                } while (innerOption != 0);
                break;

            case 3:
                do {
                    cout << "\n--- RING LINKED LIST OPERATIONS ---\n";
                    cout << "1. Register Task\n2. Delete Task\n3. Display Tasks\n";
                    cout << "4. Modify Status\n5. Execute Josephus Simulation\n0. Return\n";
                    cout << "Select choice: ";
                    cin >> innerOption;
                    switch (innerOption) {
                        case 1:
                            cout << "Task Name: "; cin >> textVal;
                            cout << "Priority Level: "; cin >> priorityVal;
                            cout << "Current Status: "; cin >> stateVal;
                            rList.insertTask(textVal, priorityVal, stateVal);
                            break;
                        case 2:
                            cout << "Task Name to Delete: "; cin >> textVal;
                            rList.deleteByName(textVal);
                            break;
                        case 3: rList.showTasks(); break;
                        case 4:
                            cout << "Task Name: "; cin >> textVal;
                            cout << "New Status: "; cin >> stateVal;
                            rList.changeStatus(textVal, stateVal);
                            break;
                        case 5:
                            cout << "Total Participants (N): "; cin >> totalCount;
                            cout << "Elimination Interval (M): "; cin >> skipStep;
                            RingTaskList::runJosephus(totalCount, skipStep);
                            break;
                    }
                } while (innerOption != 0);
                break;

            case 0:
                cout << "Exiting application gracefully.\n";
                break;

            default:
                cout << "Invalid entry. Please try again.\n";
        }
    } while (menuSelection != 0);

    return 0;
}
